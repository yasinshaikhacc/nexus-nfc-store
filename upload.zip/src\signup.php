<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            $error = "Email already registered.";
        } else {
            // Create user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            try {
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
                if ($stmt->execute([$name, $email, $hashed_password])) {
                    $success = "Registration successful! You can now login.";
                } else {
                    $error = "Something went wrong. Please try again.";
                }
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card bg-dark text-white shadow-lg rounded-5">
                <div class="card-body p-5">
                    <h2 class="fw-bold mb-4 text-center text-gradient">Create Account</h2>

                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <?= $success ?> <br>
                            <a href="login.php" class="fw-bold text-success">Login Now</a>
                        </div>
                    <?php endif; ?>

                    <form action="signup.php" method="POST">
                        <!-- Name -->
                        <div class="form-outline mb-4">
                            <input type="text" id="name" name="name" class="form-control form-control-lg text-white"
                                required />
                            <label class="form-label text-white-50" for="name">Full Name</label>
                        </div>

                        <!-- Email -->
                        <div class="form-outline mb-4">
                            <input type="email" id="email" name="email" class="form-control form-control-lg text-white"
                                required />
                            <label class="form-label text-white-50" for="email">Email address</label>
                        </div>

                        <!-- Password -->
                        <div class="form-outline mb-4">
                            <input type="password" id="password" name="password"
                                class="form-control form-control-lg text-white" required />
                            <label class="form-label text-white-50" for="password">Password</label>
                        </div>

                        <!-- Confirm Password -->
                        <div class="form-outline mb-4">
                            <input type="password" id="confirm_password" name="confirm_password"
                                class="form-control form-control-lg text-white" required />
                            <label class="form-label text-white-50" for="confirm_password">Confirm Password</label>
                        </div>

                        <button type="submit" class="btn btn-voltix-primary btn-lg w-100 mb-4">Sign Up</button>

                        <div class="text-center">
                            <p class="text-muted">Already have an account? <a href="login.php"
                                    class="text-white fw-bold">Login</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.querySelectorAll('.form-outline').forEach((formOutline) => {
        new mdb.Input(formOutline).init();
    });
</script>

<?php require_once 'includes/footer.php'; ?>