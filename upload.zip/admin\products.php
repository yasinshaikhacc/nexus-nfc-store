<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

// Mock session start
if (session_status() === PHP_SESSION_NONE)
    session_start();
if (!isAdmin())
    redirect('../login.php');

$message = '';

// Handle Add Product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = sanitize($_POST['name']);
    $price = (float) $_POST['price'];
    $category = sanitize($_POST['category']);
    $brand = sanitize($_POST['brand']);
    $description = sanitize($_POST['description']);
    $image = sanitize($_POST['image']); // In real app, handle file upload
    $stock = (int) $_POST['stock'];

    // Slug generation
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));

    try {
        $stmt = $pdo->prepare("INSERT INTO products (name, slug, category, brand, price, stock, image, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $slug, $category, $brand, $price, $stock, $image, $description]);
        $message = "Product added successfully!";
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Fetch Products
$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Products - VOLTIX Admin</title>
    <!-- Same CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background: #000;
            border-right: 1px solid #333;
            padding-top: 20px;
            z-index: 1000;
        }

        .admin-content {
            margin-left: 250px;
            padding: 30px;
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }

            .admin-content {
                margin-left: 0;
            }
        }
    </style>
</head>

<body class="dark-mode">

    <!-- Sidebar (Ideally should be an include) -->
    <nav class="admin-sidebar d-none d-md-block">
        <div class="text-center mb-4">
            <h4 class="text-gradient fw-bold"><i class="fas fa-bolt me-2"></i>VOLTIX</h4>
            <small class="text-muted">Admin Panel</small>
        </div>
        <ul class="nav flex-column px-3">
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="index.php"><i
                        class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded active bg-primary text-white" href="products.php"><i
                        class="fas fa-box me-2"></i> Products</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="orders.php"><i
                        class="fas fa-shopping-cart me-2"></i> Orders</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="users.php"><i
                        class="fas fa-users me-2"></i> Users</a></li>
            <li class="nav-item mt-auto"><a class="nav-link rounded text-danger" href="../logout.php"><i
                        class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
        </ul>
    </nav>

    <div class="admin-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-white">Products</h2>
            <button class="btn btn-success" data-mdb-modal-init data-mdb-target="#addProductModal"><i
                    class="fas fa-plus me-2"></i> Add Product</button>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-info">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <div class="card border-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle bg-transparent">
                    <thead class="bg-transparent border-bottom border-light border-opacity-10">
                        <tr>
                            <th class="text-white text-opacity-75">Image</th>
                            <th class="text-white text-opacity-75">Name</th>
                            <th class="text-white text-opacity-75">Category</th>
                            <th class="text-white text-opacity-75">Price</th>
                            <th class="text-white text-opacity-75">Stock</th>
                            <th class="text-white text-opacity-75">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $p): ?>
                            <tr>
                                <td><img src="<?= htmlspecialchars($p['image']) ?>" width="50" height="50"
                                        class="rounded-3 shadow-sm">
                                </td>
                                <td class="fw-bold">
                                    <?= htmlspecialchars($p['name']) ?>
                                </td>
                                <td>
                                    <span class="badge bg-white bg-opacity-10 text-white fw-normal">
                                        <?= htmlspecialchars($p['category']) ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="text-info"><?= formatPrice($p['price']) ?></span>
                                </td>
                                <td>
                                    <span
                                        class="badge bg-<?= $p['stock'] > 0 ? 'success' : 'danger' ?> bg-opacity-25 text-<?= $p['stock'] > 0 ? 'success' : 'danger' ?> rounded-pill">
                                        <?= $p['stock'] ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-info rounded-circle p-2"><i
                                            class="fas fa-edit"></i></button>
                                    <button class="btn btn-sm btn-outline-danger rounded-circle p-2"><i
                                            class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content glass-effect border-0 text-white">
                <div class="modal-header border-bottom border-light border-opacity-10">
                    <h5 class="modal-title">Add New Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-mdb-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <input type="hidden" name="add_product" value="1">
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" name="name" class="form-control text-white" required>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="form-label">Category</label>
                                <select name="category" class="form-select bg-dark text-white">
                                    <option>Mobiles</option>
                                    <option>Laptops</option>
                                    <option>Audio</option>
                                    <option>Gaming</option>
                                    <option>Accessories</option>
                                </select>
                            </div>
                            <div class="col-6 mb-3">
                                <label class="form-label">Brand</label>
                                <input type="text" name="brand" class="form-control text-white" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="form-label">Price</label>
                                <input type="number" step="0.01" name="price" class="form-control text-white" required>
                            </div>
                            <div class="col-6 mb-3">
                                <label class="form-label">Stock</label>
                                <input type="number" name="stock" class="form-control text-white" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Image URL</label>
                            <input type="text" name="image" class="form-control text-white"
                                value="https://placehold.co/600x400" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control text-white" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Save Product</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
    <script>
        document.querySelectorAll('.form-outline').forEach((formOutline) => {
            new mdb.Input(formOutline).init();
        });
    </script>
</body>

</html>