<?php
require_once 'config/db.php';
require_once 'includes/header.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$product = null;

if ($id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $product = $stmt->fetch();
    } catch (PDOException $e) {
        $product = null;
    }
}

if (!$product) {
    echo "<div class='container my-5 text-center'><h2 class='text-white'>Product not found.</h2><a href='products.php' class='btn btn-primary mt-3'>Back to Products</a></div>";
    require_once 'includes/footer.php';
    exit();
}
?>

<div class="container my-5 pt-3">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-muted">Home</a></li>
            <li class="breadcrumb-item"><a href="products.php" class="text-muted">Products</a></li>
            <li class="breadcrumb-item active text-white" aria-current="page">
                <?= htmlspecialchars($product['name']) ?>
            </li>
        </ol>
    </nav>

    <div class="row g-5">
        <!-- Product Image -->
        <div class="col-lg-6">
            <div class="card p-5 border-0 bg-transparent text-center">
                <img src="<?= htmlspecialchars($product['image']) ?>" class="img-fluid rounded-5 shadow-lg"
                    alt="<?= htmlspecialchars($product['name']) ?>" style="max-height: 500px;">
            </div>

            <!-- Thumbnails (Static for now) -->
            <div class="d-flex justify-content-center mt-3 gap-2">
                <img src="<?= htmlspecialchars($product['image']) ?>" class="rounded-3 border border-primary p-1"
                    width="60" height="60">
                <img src="<?= htmlspecialchars($product['image']) ?>" class="rounded-3 border border-secondary p-1"
                    width="60" height="60" style="opacity: 0.5">
                <img src="<?= htmlspecialchars($product['image']) ?>" class="rounded-3 border border-secondary p-1"
                    width="60" height="60" style="opacity: 0.5">
            </div>
        </div>

        <!-- Product Info -->
        <div class="col-lg-6">
            <h6 class="text-uppercase text-secondary fw-bold letter-spacing-2">
                <?= htmlspecialchars($product['brand']) ?> /
                <?= htmlspecialchars($product['category']) ?>
            </h6>
            <h1 class="display-4 fw-bold text-white mb-3">
                <?= htmlspecialchars($product['name']) ?>
            </h1>

            <div class="d-flex align-items-center mb-4">
                <div class="text-warning me-3">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <span class="text-muted small">(150 Reviews)</span>

                <?php if ($product['stock'] > 0): ?>
                    <span class="badge bg-success ms-3 px-3 py-2 rounded-pill">In Stock</span>
                <?php else: ?>
                    <span class="badge bg-danger ms-3 px-3 py-2 rounded-pill">Out of Stock</span>
                <?php endif; ?>
            </div>

            <h2 class="display-5 fw-bold text-gradient mb-4">
                <?= formatPrice($product['sale_price'] ?? $product['price']) ?>
                <?php if ($product['sale_price']): ?>
                    <small class="text-muted text-decoration-line-through fs-4 ms-2">
                        <?= formatPrice($product['price']) ?>
                    </small>
                <?php endif; ?>
            </h2>

            <p class="text-muted lead mb-5">
                <?= nl2br(htmlspecialchars($product['description'])) ?>
            </p>

            <!-- Actions -->
            <form action="cart.php" method="post">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">

                <div class="row g-3 mb-4">
                    <div class="col-sm-4 col-md-3">
                        <div class="form-outline">
                            <input type="number" name="quantity" id="typeNumber"
                                class="form-control form-control-lg text-white" value="1" min="1"
                                max="<?= $product['stock'] ?>" />
                            <label class="form-label text-white-50" for="typeNumber">Quantity</label>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-9">
                        <button type="submit" class="btn btn-voltix-primary btn-lg w-100 h-100">
                            <i class="fas fa-cart-shopping me-2"></i> Add to Cart
                        </button>
                    </div>
                </div>
                <!-- Buy Now (Link to checkout immediately) -->
                <button type="button" class="btn btn-outline-light btn-lg w-100">Buy Now</button>
            </form>

            <hr class="my-5 border-secondary">

            <!-- Specs (If JSON) -->
            <?php
            $specs = json_decode($product['specifications'] ?? '{}', true);
            if ($specs):
                ?>
                <h4 class="text-white mb-4">Specifications</h4>
                <div class="row">
                    <?php foreach ($specs as $key => $val): ?>
                        <div class="col-md-6 mb-3">
                            <strong class="text-white">
                                <?= htmlspecialchars($key) ?>:
                            </strong> <span class="text-muted">
                                <?= htmlspecialchars($val) ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>

    <!-- Related Products -->
    <div class="mt-5 pt-5">
        <h3 class="text-white fw-bold mb-4">You might also like</h3>
        <!-- Placeholder for related products -->
        <p class="text-muted">Related products will look just like the main grid.</p>
    </div>
</div>

<script>
    // Initialize MDB inputs
    document.querySelectorAll('.form-outline').forEach((formOutline) => {
        new mdb.Input(formOutline).init();
    });
</script>

<?php require_once 'includes/footer.php'; ?>