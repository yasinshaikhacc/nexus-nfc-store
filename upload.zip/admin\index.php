<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

// Mock session start if not already (functions.php has it, but just in case of different path inclusion)
if (session_status() === PHP_SESSION_NONE)
    session_start();

if (!isAdmin()) {
    redirect('../login.php');
}

// Stats
$stats = [
    'users' => 0,
    'orders' => 0,
    'products' => 0,
    'revenue' => 0
];

try {
    $stats['users'] = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $stats['orders'] = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
    $stats['products'] = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    $stats['revenue'] = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE payment_status = 'paid'")->fetchColumn() ?: 0;
} catch (PDOException $e) {
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - VOLTIX</title>
    <!-- Same CSS as main site -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background: rgba(10, 10, 10, 0.8);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            padding-top: 20px;
            z-index: 1000;
        }

        .admin-content {
            margin-left: 250px;
            padding: 30px;
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }

            .admin-content {
                margin-left: 0;
            }
        }

        .nav-link.active {
            background: linear-gradient(90deg, rgba(98, 0, 234, 0.2), transparent);
            border-left: 3px solid var(--neon-purple);
            color: #fff !important;
        }

        .nav-link {
            color: #aaa;
            transition: all 0.3s;
            padding: 10px 15px;
        }

        .nav-link:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }
    </style>
</head>

<body class="dark-mode">

    <!-- Sidebar -->
    <nav class="admin-sidebar d-none d-md-block glass-effect">
        <div class="text-center mb-4 pt-3">
            <h4 class="text-gradient fw-bold"><i class="fas fa-bolt me-2"></i>VOLTIX</h4>
            <small class="text-muted">Admin Panel</small>
        </div>
        <ul class="nav flex-column px-3">
            <li class="nav-item mb-2">
                <a class="nav-link active rounded" href="index.php"><i class="fas fa-tachometer-alt me-2"></i>
                    Dashboard</a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link rounded" href="products.php"><i class="fas fa-box me-2"></i> Products</a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link rounded" href="orders.php"><i class="fas fa-shopping-cart me-2"></i> Orders</a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link rounded" href="users.php"><i class="fas fa-users me-2"></i> Users</a>
            </li>
            <li class="nav-item mt-auto">
                <a class="nav-link rounded text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>
                    Logout</a>
            </li>
        </ul>
    </nav>

    <!-- Mobile Navbar -->
    <nav class="navbar navbar-dark d-md-none p-3 glass-header">
        <span class="navbar-brand text-gradient fw-bold">VOLTIX Admin</span>
        <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i></a>
    </nav>

    <!-- Main Content -->
    <div class="admin-content">
        <h2 class="text-white mb-4">Dashboard Overview</h2>

        <div class="row g-4">
            <!-- Card 1 -->
            <div class="col-md-3">
                <div class="card border-0">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">Total Orders</p>
                                <h3 class="fw-bold mb-0 text-white">
                                    <?= $stats['orders'] ?>
                                </h3>
                            </div>
                            <div class="p-3 bg-primary rounded-circle bg-opacity-10 text-primary box-shadow-glow">
                                <i class="fas fa-shopping-bag fa-lg"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="col-md-3">
                <div class="card border-0">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">Total Revenue</p>
                                <h3 class="fw-bold mb-0 text-white">
                                    <?= formatPrice($stats['revenue']) ?>
                                </h3>
                            </div>
                            <div class="p-3 bg-success rounded-circle bg-opacity-10 text-success box-shadow-glow">
                                <i class="fas fa-dollar-sign fa-lg"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="col-md-3">
                <div class="card border-0">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">Products</p>
                                <h3 class="fw-bold mb-0 text-white">
                                    <?= $stats['products'] ?>
                                </h3>
                            </div>
                            <div class="p-3 bg-warning rounded-circle bg-opacity-10 text-warning box-shadow-glow">
                                <i class="fas fa-box fa-lg"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="col-md-3">
                <div class="card border-0">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">Users</p>
                                <h3 class="fw-bold mb-0 text-white">
                                    <?= $stats['users'] ?>
                                </h3>
                            </div>
                            <div class="p-3 bg-info rounded-circle bg-opacity-10 text-info box-shadow-glow">
                                <i class="fas fa-users fa-lg"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Tables placeholder -->
        <div class="row mt-5">
            <div class="col-md-12">
                <div class="card border-0">
                    <div class="card-header border-bottom border-light border-opacity-10 bg-transparent">
                        <h5 class="mb-0 text-white">Recent Activity</h5>
                    </div>
                    <div class="card-body text-center py-5 text-muted">
                        <i class="fas fa-chart-line fa-3x mb-3 text-secondary opacity-50"></i>
                        <p>No recent activity data available.</p>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
</body>

</html>