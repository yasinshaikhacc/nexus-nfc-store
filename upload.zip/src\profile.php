<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$user = null;
$orders = [];

try {
    // Fetch User Info
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    // Fetch Orders
    $stmtOrders = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
    $stmtOrders->execute([$user_id]);
    $orders = $stmtOrders->fetchAll();

} catch (PDOException $e) {
    // Handle error
}
?>

<div class="container my-5 pt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card bg-dark text-white p-3">
                <div class="text-center mb-3">
                    <img src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp" class="rounded-circle mb-3" width="100">
                    <h5 class="fw-bold">
                        <?= htmlspecialchars($user['name']) ?>
                    </h5>
                    <p class="text-muted small">
                        <?= htmlspecialchars($user['email']) ?>
                    </p>
                </div>
                <div class="list-group list-group-light">
                    <a href="#" class="list-group-item list-group-item-action text-white bg-transparent border-0 active"
                        aria-current="true">
                        <i class="fas fa-user-circle me-2"></i> Dashboard
                    </a>
                    <a href="#" class="list-group-item list-group-item-action text-white-50 bg-transparent border-0">
                        <i class="fas fa-box me-2"></i> My Orders
                    </a>
                    <a href="#" class="list-group-item list-group-item-action text-white-50 bg-transparent border-0">
                        <i class="fas fa-cog me-2"></i> Settings
                    </a>
                    <a href="logout.php"
                        class="list-group-item list-group-item-action text-danger bg-transparent border-0">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="col-lg-9">
            <h2 class="text-white mb-4">Dashboard</h2>

            <div class="row g-4 mb-5">
                <div class="col-md-4">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Orders</h5>
                            <h2 class="display-6 fw-bold">
                                <?= count($orders) ?>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-success text-white h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Spent</h5>
                            <h2 class="display-6 fw-bold">
                                <?php
                                $total = 0;
                                foreach ($orders as $o)
                                    $total += $o['total_amount'];
                                echo formatPrice($total);
                                ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>

            <h3 class="text-white mb-3">Recent Orders</h3>
            <div class="card bg-dark text-white">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($orders)): ?>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td>#
                                                <?= $order['id'] ?>
                                            </td>
                                            <td>
                                                <?= date('M d, Y', strtotime($order['order_date'])) ?>
                                            </td>
                                            <td>
                                                <span
                                                    class="badge rounded-pill bg-<?= $order['status'] == 'delivered' ? 'success' : ($order['status'] == 'processing' ? 'warning' : 'secondary') ?>">
                                                    <?= ucfirst($order['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?= formatPrice($order['total_amount']) ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-light">View</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">No orders found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>