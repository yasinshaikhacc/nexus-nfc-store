<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if (session_status() === PHP_SESSION_NONE)
    session_start();
if (!isAdmin())
    redirect('../login.php');

// Handle Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = (int) $_POST['order_id'];
    $status = $_POST['status'];
    try {
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $order_id]);
    } catch (PDOException $e) {
    }
}

// Fetch Orders
$orders = $pdo->query("SELECT o.*, u.name as user_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.order_date DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Orders - VOLTIX Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        <style>.admin-sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background: rgba(10, 10, 10, 0.8);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            padding-top: 20px;
            z-index: 1000;
        }

        .admin-content {
            margin-left: 250px;
            padding: 30px;
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }

            .admin-content {
                margin-left: 0;
            }
        }

        .nav-link.active {
            background: linear-gradient(90deg, rgba(98, 0, 234, 0.2), transparent);
            border-left: 3px solid var(--neon-purple);
            color: #fff !important;
        }

        .nav-link {
            color: #aaa;
            transition: all 0.3s;
            padding: 10px 15px;
        }

        .nav-link:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }
    </style>
</head>

<body class="dark-mode">
    <nav class="admin-sidebar d-none d-md-block glass-effect">
        <div class="text-center mb-4 pt-3">
            <h4 class="text-gradient fw-bold"><i class="fas fa-bolt me-2"></i>VOLTIX</h4>
            <small class="text-muted">Admin Panel</small>
        </div>
        <ul class="nav flex-column px-3">
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="index.php"><i
                        class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="products.php"><i
                        class="fas fa-box me-2"></i> Products</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded active bg-primary text-white" href="orders.php"><i
                        class="fas fa-shopping-cart me-2"></i> Orders</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="users.php"><i
                        class="fas fa-users me-2"></i> Users</a></li>
            <li class="nav-item mt-auto"><a class="nav-link rounded text-danger" href="../logout.php"><i
                        class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
        </ul>
    </nav>

    <!-- Mobile Navbar -->
    <nav class="navbar navbar-dark d-md-none p-3 glass-header">
        <span class="navbar-brand text-gradient fw-bold">VOLTIX Admin</span>
        <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i></a>
    </nav>

    <div class="admin-content">
        <h2 class="text-white mb-4">Orders</h2>

        <div class="card border-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle bg-transparent">
                    <thead class="bg-transparent border-bottom border-light border-opacity-10">
                        <tr>
                            <th class="text-white text-opacity-75">Order ID</th>
                            <th class="text-white text-opacity-75">Customer</th>
                            <th class="text-white text-opacity-75">Date</th>
                            <th class="text-white text-opacity-75">Total</th>
                            <th class="text-white text-opacity-75">Status</th>
                            <th class="text-white text-opacity-75">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td class="text-secondary">#<?= $order['id'] ?></td>
                                <td class="fw-bold">
                                    <?= htmlspecialchars($order['user_name']) ?>
                                </td>
                                <td>
                                    <?= date('M d, Y', strtotime($order['order_date'])) ?>
                                </td>
                                <td class="text-white">
                                    <?= formatPrice($order['total_amount']) ?>
                                </td>
                                <td>
                                    <span
                                        class="badge rounded-pill bg-<?= $order['status'] == 'delivered' ? 'success' : ($order['status'] == 'processing' ? 'warning' : 'secondary') ?> bg-opacity-25 text-<?= $order['status'] == 'delivered' ? 'success' : ($order['status'] == 'processing' ? 'warning' : 'secondary') ?>">
                                        <?= ucfirst($order['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                        <input type="hidden" name="update_status" value="1">
                                        <select name="status"
                                            class="form-select form-select-sm bg-dark text-white border-secondary d-inline-block w-auto"
                                            onchange="this.form.submit()">
                                            <option value="processing" <?= $order['status'] == 'processing' ? 'selected' : '' ?>>Processing</option>
                                            <option value="shipped" <?= $order['status'] == 'shipped' ? 'selected' : '' ?>>
                                                Shipped</option>
                                            <option value="delivered" <?= $order['status'] == 'delivered' ? 'selected' : '' ?>>
                                                Delivered</option>
                                        </select>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>