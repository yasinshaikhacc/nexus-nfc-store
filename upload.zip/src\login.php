<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../includes/functions.php';

// Logic BEFORE header.php inclusion to prevent "headers already sent"
if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Login Success
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];

                redirect('index.php');
            } else {
                $error = "Invalid email or password.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

// Now include header which outputs HTML
require_once '../includes/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card bg-dark text-white shadow-lg rounded-5">
                <div class="card-body p-5">
                    <h2 class="fw-bold mb-4 text-center text-gradient">Welcome Back</h2>

                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <?= $error ?>
                        </div>
                    <?php endif; ?>

                    <form action="login.php" method="POST">
                        <!-- Email -->
                        <!-- Email -->
                        <div class="mb-4">
                            <label class="form-label text-white-50" for="email">Email address</label>
                            <input type="email" id="email" name="email" class="form-control form-control-lg text-white"
                                value="admin@voltix.com" required />
                        </div>

                        <!-- Password -->
                        <!-- Password -->
                        <div class="mb-4">
                            <label class="form-label text-white-50" for="password">Password</label>
                            <input type="password" id="password" name="password"
                                class="form-control form-control-lg text-white" value="admin123" required />
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <!-- Checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="rememberMe" checked />
                                <label class="form-check-label text-muted" for="rememberMe"> Remember me </label>
                            </div>
                            <a href="#!" class="text-muted small">Forgot password?</a>
                        </div>

                        <button type="submit" class="btn btn-voltix-primary btn-lg w-100 mb-4">Login</button>

                        <div class="text-center">
                            <p class="text-muted">Not a member? <a href="signup.php" class="text-white fw-bold">Sign
                                    Up</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.querySelectorAll('.form-outline').forEach((formOutline) => {
        new mdb.Input(formOutline).init();
    });
</script>

<?php require_once '../includes/footer.php'; ?>