<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

if (session_status() === PHP_SESSION_NONE)
    session_start();
if (!isAdmin())
    redirect('../login.php');

// Fetch Users
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Users - VOLTIX Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        <style>.admin-sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background: rgba(10, 10, 10, 0.8);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            padding-top: 20px;
            z-index: 1000;
        }

        .admin-content {
            margin-left: 250px;
            padding: 30px;
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }

            .admin-content {
                margin-left: 0;
            }
        }

        .nav-link.active {
            background: linear-gradient(90deg, rgba(98, 0, 234, 0.2), transparent);
            border-left: 3px solid var(--neon-purple);
            color: #fff !important;
        }

        .nav-link {
            color: #aaa;
            transition: all 0.3s;
            padding: 10px 15px;
        }

        .nav-link:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }
    </style>
</head>

<body class="dark-mode">
    <nav class="admin-sidebar d-none d-md-block glass-effect">
        <div class="text-center mb-4 pt-3">
            <h4 class="text-gradient fw-bold"><i class="fas fa-bolt me-2"></i>VOLTIX</h4>
            <small class="text-muted">Admin Panel</small>
        </div>
        <ul class="nav flex-column px-3">
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="index.php"><i
                        class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="products.php"><i
                        class="fas fa-box me-2"></i> Products</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded text-muted" href="orders.php"><i
                        class="fas fa-shopping-cart me-2"></i> Orders</a></li>
            <li class="nav-item mb-2"><a class="nav-link rounded active bg-primary text-white" href="users.php"><i
                        class="fas fa-users me-2"></i> Users</a></li>
            <li class="nav-item mt-auto"><a class="nav-link rounded text-danger" href="../logout.php"><i
                        class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
        </ul>
    </nav>

    <!-- Mobile Navbar -->
    <nav class="navbar navbar-dark d-md-none p-3 glass-header">
        <span class="navbar-brand text-gradient fw-bold">VOLTIX Admin</span>
        <a href="../logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i></a>
    </nav>

    <div class="admin-content">
        <h2 class="text-white mb-4">Users</h2>

        <div class="card border-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0 align-middle bg-transparent">
                    <thead class="bg-transparent border-bottom border-light border-opacity-10">
                        <tr>
                            <th class="text-white text-opacity-75">ID</th>
                            <th class="text-white text-opacity-75">Name</th>
                            <th class="text-white text-opacity-75">Email</th>
                            <th class="text-white text-opacity-75">Role</th>
                            <th class="text-white text-opacity-75">Joined</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td class="text-secondary">#
                                    <?= $u['id'] ?>
                                </td>
                                <td class="fw-bold">
                                    <?= htmlspecialchars($u['name']) ?>
                                </td>
                                <td>
                                    <?= htmlspecialchars($u['email']) ?>
                                </td>
                                <td>
                                    <span
                                        class="badge rounded-pill bg-<?= $u['role'] == 'admin' ? 'danger' : 'primary' ?> bg-opacity-25 text-<?= $u['role'] == 'admin' ? 'danger' : 'primary' ?>">
                                        <?= ucfirst($u['role']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?= date('M d, Y', strtotime($u['created_at'])) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>