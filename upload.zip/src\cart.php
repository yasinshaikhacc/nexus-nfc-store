<?php
require_once '../config/db.php';
require_once '../includes/functions.php';

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $product_id = (int) $_POST['product_id'];

    if ($_POST['action'] === 'add') {
        $quantity = isset($_POST['quantity']) ? (int) $_POST['quantity'] : 1;

        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id] += $quantity;
        } else {
            $_SESSION['cart'][$product_id] = $quantity;
        }

        setFlashMessage('success', 'Product added to cart!');
    } elseif ($_POST['action'] === 'update') {
        $quantity = (int) $_POST['quantity'];
        if ($quantity > 0) {
            $_SESSION['cart'][$product_id] = $quantity;
        } else {
            unset($_SESSION['cart'][$product_id]);
        }
        setFlashMessage('info', 'Cart updated!');
    } elseif ($_POST['action'] === 'remove') {
        unset($_SESSION['cart'][$product_id]);
        setFlashMessage('warning', 'Item removed from cart!');
    }

    // AJAX Check
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        // Calculate totals
        $new_cart_count = 0;
        $total_price = 0;
        $item_subtotal = 0;

        if (!empty($_SESSION['cart'])) {
            $ids = implode(',', array_keys($_SESSION['cart']));
            $stmt = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
            $products = $stmt->fetchAll();
            foreach ($products as $p) {
                $qty = $_SESSION['cart'][$p['id']];
                $price = $p['sale_price'] ?? $p['price'];
                $sub = $price * $qty;
                $total_price += $sub;
                $new_cart_count += $qty;
                if ($p['id'] == $product_id) {
                    $item_subtotal = $sub;
                }
            }
        }

        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => 'Cart updated successfully',
            'cart_count' => $new_cart_count,
            'item_subtotal' => formatPrice($item_subtotal),
            'total_price' => formatPrice($total_price),
            'total_with_tax' => formatPrice($total_price * 1.1),
            'tax' => formatPrice($total_price * 0.1)
        ]);
        exit();
    }

    // Standard redirect to avoid form resubmission
    redirect('cart.php');
}

require_once '../includes/header.php';

// Initialize Cart
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Fetch Cart Products
$cartProducts = [];
$totalPrice = 0;

if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    try {
        $stmt = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
        $products = $stmt->fetchAll();

        foreach ($products as $p) {
            $p['qty'] = $_SESSION['cart'][$p['id']];
            $p['subtotal'] = ($p['sale_price'] ?? $p['price']) * $p['qty'];
            $totalPrice += $p['subtotal'];
            $cartProducts[] = $p;
        }
    } catch (PDOException $e) {
        // Handle error
    }
}
?>

<div class="container my-5 pt-4">
    <h2 class="text-white mb-4">Shopping Cart</h2>

    <?php
    $flash = getFlashMessage();
    if ($flash):
        ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <?php if (!empty($cartProducts)): ?>
            <div class="col-lg-8">
                <div class="card mb-4 border-0">
                    <div class="card-body">
                        <?php foreach ($cartProducts as $item): ?>
                            <div class="row align-items-center mb-4 border-bottom border-secondary pb-4">
                                <div class="col-md-2">
                                    <img src="<?= htmlspecialchars($item['image']) ?>" class="img-fluid rounded-3"
                                        alt="<?= htmlspecialchars($item['name']) ?>">
                                </div>
                                <div class="col-md-4">
                                    <h5 class="mb-1 text-white">
                                        <?= htmlspecialchars($item['name']) ?>
                                    </h5>
                                    <p class="text-muted small mb-0">
                                        <?= htmlspecialchars($item['brand']) ?>
                                    </p>
                                </div>
                                <div class="col-md-3">
                                    <div class="d-flex align-items-center">
                                        <form action="cart.php" method="POST" class="d-flex align-items-center"
                                            onsubmit="handleCartAction(event)">
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                                            <div class="input-group input-group-sm quantity-group">
                                                <button type="button" class="btn btn-outline-secondary btn-qty"
                                                    onclick="updateQty(this, -1)">-</button>
                                                <input type="number" name="quantity" value="<?= $item['qty'] ?>" min="1"
                                                    class="form-control text-center text-white bg-transparent border-secondary qty-input"
                                                    style="width: 50px;"
                                                    onchange="this.form.dispatchEvent(new Event('submit', {cancelable: true, bubbles: true}))">
                                                <button type="button" class="btn btn-outline-secondary btn-qty"
                                                    onclick="updateQty(this, 1)">+</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-md-3 text-end">
                                    <h5 class="mb-2 text-white">
                                        <?= formatPrice($item['subtotal']) ?>
                                    </h5>
                                    <form action="cart.php" method="POST" onsubmit="handleCartAction(event)">
                                        <input type="hidden" name="action" value="remove">
                                        <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                                        <button type="submit" class="btn btn-sm text-danger p-0"><i
                                                class="fas fa-trash me-1"></i> Remove</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card border-0">
                    <div class="card-body">
                        <h5 class="card-title mb-4 text-white">Order Summary</h5>
                        <div class="d-flex justify-content-between mb-3 text-muted">
                            <span>Subtotal</span>
                            <span class="text-white"><?= formatPrice($totalPrice) ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-3 text-muted">
                            <span>Shipping</span>
                            <span class="text-success">Free</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3 text-muted">
                            <span>Tax (Estimated)</span>
                            <span class="text-white"><?= formatPrice($totalPrice * 0.1) ?></span>
                        </div>
                        <hr class="border-secondary">
                        <div class="d-flex justify-content-between mb-4">
                            <strong class="fs-5 text-white">Total</strong>
                            <strong class="fs-5 text-gradient"><?= formatPrice($totalPrice * 1.1) ?></strong>
                        </div>

                        <a href="checkout.php" class="btn btn-voltix-primary w-100 btn-lg mb-3">Proceed to Checkout</a>
                        <a href="products.php" class="btn btn-outline-voltix w-100">Continue Shopping</a>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-shopping-cart fa-4x text-muted mb-4"></i>
                <h3 class="text-white">Your cart is empty</h3>
                <p class="text-muted mb-4">Looks like you haven't added anything to your cart yet.</p>
                <a href="products.php" class="btn btn-primary btn-lg">Start Shopping</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    function updateQty(btn, delta) {
        const input = btn.parentElement.querySelector('.qty-input');
        let newValue = parseInt(input.value) + delta;
        if (newValue < 1) newValue = 1;
        input.value = newValue;
        input.dispatchEvent(new Event('change'));
    }
</script>

<?php require_once '../includes/footer.php'; ?>